package org.jyothi.tutorials;

public class IPLocationFinder {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (args.length !=1 ){
System.out.println(" you need to pass in one IP address");
		}
		else {
			String ipAddress= args[0];
			stub.getCountryName(ipAddress);
			
			
		}
	}

}
