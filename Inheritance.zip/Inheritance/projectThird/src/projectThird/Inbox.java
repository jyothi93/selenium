package projectThird;

public class Inbox {

	public void inbox_TC() {
		
		System.out.println("This is for test inbox functionality");
		
	}
	
	public static void main(String args[]) {
		Login login=new Login();
		login.doLogin_TC();
		
		Inbox inbox=new Inbox();
		inbox.inbox_TC();
		
	}
	
}

