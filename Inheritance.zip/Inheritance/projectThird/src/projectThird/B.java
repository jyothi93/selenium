package projectThird;

public class B extends A {
	
	public void div() {
		System.out.println("This is div funn");
	}

	public static void main(String args[] ) {
		
		B b=new B();
		b.div();
		b.add();
	}

}
