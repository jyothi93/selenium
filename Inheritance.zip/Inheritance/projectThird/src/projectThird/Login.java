package projectThird;

public class Login {
	
	public void doLogin_TC() {
		
		System.out.println("This is for test login functionality ");
		
	}

}
