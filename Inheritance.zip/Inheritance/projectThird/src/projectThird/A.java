package projectThird;

public class A {

	public void add() {
		
		System.out.println("This is add fun");
	} 
}
 