package javabasics;

public class Variables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int userID;
    
    int empID =30;
    
    userID = 12;
    userID =16;
    System.out.println(userID);
    System.out.println(empID);
    
    
    		
	}

}
