package javabasics;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Assignment operator
		int userID =15;
		// arithmetic operator + - * / %
		int a=4,b=2;
		System.out.println(a*b);
		
		// increment/Decrement operators ++ --
		a++;
		b--;
		//System.out.println(a);
		//System.out.println(b);
		
		// Equality and rational operators == != > < <= >=
		
		a=10;
		b=15;
		//System.out.println(a==b);
		//System.out.println(a<b);
		int c=50;
		// conditional operators && ||
		
		if (c>a || c<b)
		{
		System.out.println("c is bigger than a and b");
		}
		
		
		
		
		
		

		
		
		
	}

}
