package javabasics;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] productTypes = {"laptop","Phone","Tablet"};
		
		productTypes[0] = "desktop";
		
		double[] productPrices = new double[3];
		productPrices[0] = 299.5;
		productPrices[1] = 199.5;
		productPrices[2] = 99.25;
		
		System.out.println(productTypes[0]);
		System.out.println(productTypes[1]);
		System.out.println(productTypes[2]);
		
		System.out.println(productPrices[0]);
		System.out.println(productPrices[1]);
		System.out.println("Length:" +productPrices.length);
		
	}

}
