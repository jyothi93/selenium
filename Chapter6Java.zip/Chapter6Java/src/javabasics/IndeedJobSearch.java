package javabasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class IndeedJobSearch {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
        // create firefox driver to drive the browser
		WebDriver driver = new FirefoxDriver();
		//System.setProperty("webdriver.chrome.driver", 
				//"C:\\Users\\jyothi\\Desktop\\tutorials\\New folder\\chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
		String baseURL = "http://www.indeed.co.uk";
		// open Indeed Home page
		driver.get(baseURL);
		// Find what field and enter Selenium
		Thread.sleep(2000);
		driver.findElement(By.id("what")).sendKeys("Selenium");
		// Find location field and enter London
		driver.findElement(By.id("where")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("where")).sendKeys("London");
		// Find Findjobs button and click on it
		Thread.sleep(2000);
		driver.findElement(By.id("fj")).click();
		// From job search results page,get page tittle and jobs count message
		// searchCount
		
		System.out.println(driver.getTitle());
		System.out.println(driver.findElement(By.id("searchCount")).getText());
		driver.close();
	}

}
