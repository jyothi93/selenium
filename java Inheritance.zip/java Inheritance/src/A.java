import java.util.concurrent.SynchronousQueue;

public class A {

	public void add() {
		System.out.println("This is A class add fun");
		
	}
}
