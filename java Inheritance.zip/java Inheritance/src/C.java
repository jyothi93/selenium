
public class C extends B{

	public void sub() {
		System.out.println("This is C class sub fun");
	}
	
public static void main(String[] args) {
	
	C c=new C();
	c.sub();
	c.div();
	c.add();
	}
}
