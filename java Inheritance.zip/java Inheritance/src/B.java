
public class B extends A {

	public void div() {
		System.out.println("This is B class div fun");
	}
	public static void main(String[] args) {
		B bObj=new B();
		bObj.div();
		bObj.add();
		// To call A class fun , we need to create A class object
	}
}
