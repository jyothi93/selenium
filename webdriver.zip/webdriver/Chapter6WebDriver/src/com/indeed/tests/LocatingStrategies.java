package com.indeed.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LocatingStrategies {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
        // create firefox driver to drive the browser
		WebDriver driver = new FirefoxDriver();
		
		// open Indeed Home page
		driver.get("http://www.indeed.co.uk");
		// Locating by ID
		// driver.findElement(By.id("what")).sendKeys("Selenium");
		
		// Locating by Name
		//driver.findElement(By.name("q")).sendKeys("Selenium");
		// Locating by Text
		//driver.findElement(By.linkText("Upload your CV")).click();
		// Locating by PartialLinkText
		//driver.findElement(By.partialLinkText("Post Job")).click();
		// Locating by Xpath
		
		//System.out.println(
		//driver.findElement(By.xpath("//img[@title='Indeed job search']"))
				//.getAttribute("src"));
		
	// Locating by CssSelector
		
		// System.out.println(
				
		//	driver.findElement(By.cssSelector("input.input_submit"))
		//		.getAttribute("value")
				
		//		);
		
		// Locating by TagName
		
		//		System.out.println(
						
		//			driver.findElements(By.tagName("a")).size()
					
		//				);
				
		//		System.out.println(
						
		//				driver.findElement(By.tagName("a"))
						
		//				.getText()
						
		//					);
		// Locating by Class Name
				
				System.out.println(
						
					driver.findElements(By.className("input_text")).size()
					
						);
				driver.findElement(By.className("input_text"))
				.sendKeys("Selenium");
	
							
	}
		
}
